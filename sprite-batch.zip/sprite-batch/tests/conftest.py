from __future__ import annotations

from pathlib import Path

import pytest
from PIL import Image, ImageDraw

from spritebatch.catalog import RedSettings, ScaleSettings, ShadowSettings, SpriteSpec

ARTIFACTS_OUT = Path(__file__).parent / "artifacts_output"


class ImageArtifactWriter:
    """Accumula immagini etichettate e le salva affiancate su fondo chiaro."""

    def __init__(self) -> None:
        self.layers: list[tuple[str, Image.Image]] = []

    def add(self, image: Image.Image, layer: str) -> None:
        self.layers.append((layer, image.copy()))

    def has_content(self) -> bool:
        return bool(self.layers)

    def save(self, path: Path) -> None:
        pad, label_h = 8, 16
        width = sum(im.width for _, im in self.layers) + pad * (len(self.layers) + 1)
        height = max(im.height for _, im in self.layers) + pad * 2 + label_h
        sheet = Image.new("RGBA", (width, height), (235, 235, 235, 255))
        draw = ImageDraw.Draw(sheet)
        x = pad
        for layer, im in self.layers:
            sheet.alpha_composite(im.convert("RGBA"), (x, pad + label_h))
            draw.text((x, 2), layer, fill=(40, 40, 40, 255))
            x += im.width + pad
        sheet.save(path)


@pytest.fixture
def artifact_writer(request):
    writer = ImageArtifactWriter()
    yield writer
    if writer.has_content():
        ARTIFACTS_OUT.mkdir(parents=True, exist_ok=True)
        writer.save(ARTIFACTS_OUT / f"{request.node.name}.png")


@pytest.fixture
def scale() -> ScaleSettings:
    return ScaleSettings()


@pytest.fixture
def shadow() -> ShadowSettings:
    return ShadowSettings()


@pytest.fixture
def red() -> RedSettings:
    return RedSettings()


def make_spec(**overrides) -> SpriteSpec:
    values = dict(
        name="prova",
        category="C3",
        kind="oggetto",
        canvas=512,
        scale_mode="canvas",
        red_mode="libero",
        subject="Test subject",
        size_m=None,
        shadow=True,
        folders=("textures/objects",),
    )
    values.update(overrides)
    return SpriteSpec(**values)


def house_image(size: int = 400, box: tuple[int, int, int, int] = (100, 120, 300, 280),
                roof=(190, 45, 30, 255), wall=(128, 112, 92, 255), background=(0, 0, 0, 0)) -> Image.Image:
    """Casa sintetica: muro marrone con tetto rosso interno, su sfondo configurabile."""
    img = Image.new("RGBA", (size, size), background)
    draw = ImageDraw.Draw(img)
    draw.rectangle(box, fill=wall)
    l, t, r, b = box
    inset = min(20, max(1, min(r - l, b - t) // 5))
    draw.rectangle((l + inset, t + inset, r - inset, b - inset), fill=roof)
    return img
