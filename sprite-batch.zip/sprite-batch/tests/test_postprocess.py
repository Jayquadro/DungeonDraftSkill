from __future__ import annotations

import numpy as np
import pytest
from PIL import Image

from conftest import house_image, make_spec
from spritebatch import postprocess as pp
from spritebatch.catalog import ScaleSettings, ShadowSettings


class Test_Geometry_Transforms:
    def test_geometry_object_side_for_canvas_without_shadow(self, scale):
        # (256 - 25.6) / 0.5 = 460.8
        assert pp.object_side_for_canvas(512, scale, None) == 460

    def test_geometry_object_side_for_canvas_with_shadow(self, scale, shadow):
        # (256 - 25.6) / (0.5 + 0.09) = 390.5
        assert pp.object_side_for_canvas(512, scale, shadow) == 390

    def test_geometry_canvas_for_object_rounded(self, scale, shadow):
        # 512 * 0.59 / 0.45 = 671.3 -> 672
        assert pp.canvas_for_object(512, scale, shadow) == 672

    def test_geometry_canvas_for_object_inverse_invariant(self, scale, shadow):
        for side in (1, 17, 256, 341, 512, 853, 1024):
            canvas = pp.canvas_for_object(side, scale, shadow)
            assert pp.object_side_for_canvas(canvas, scale, shadow) >= side

    def test_geometry_target_real_scale_cart(self, scale, shadow):
        spec = make_spec(scale_mode="reale", size_m=(3.0, 1.5), canvas=256)
        assert pp.target_geometry(spec, scale, shadow) == (512, 672)

    def test_geometry_target_real_scale_keeps_larger_catalog_canvas(self, scale, shadow):
        spec = make_spec(scale_mode="reale", size_m=(1.5, 1.5), canvas=1024)
        assert pp.target_geometry(spec, scale, shadow) == (256, 1024)

    def test_geometry_target_canvas_mode_ignores_size(self, scale, shadow):
        spec = make_spec(scale_mode="canvas", size_m=(30.0,), canvas=1024)
        side, canvas = pp.target_geometry(spec, scale, shadow)
        assert canvas == 1024
        assert side == pp.object_side_for_canvas(1024, scale, shadow)

    def test_geometry_place_centered_symmetric_margins(self, artifact_writer):
        obj = Image.new("RGBA", (200, 100), (120, 100, 80, 255))
        placed = pp.place_centered(obj, side=390, canvas=512)
        artifact_writer.add(obj, layer="before")
        artifact_writer.add(placed, layer="after")
        left, top, right, bottom = pp.alpha_bbox(placed)
        assert right - left == 390
        assert left == 512 - right
        assert abs(top - (512 - bottom)) <= 1

    def test_geometry_place_centered_degenerate_one_pixel(self):
        obj = Image.new("RGBA", (1, 1), (10, 10, 10, 255))
        placed = pp.place_centered(obj, side=3, canvas=16)
        assert pp.alpha_bbox(placed) is not None


class Test_Alpha_Predicates:
    def test_alpha_has_real_alpha_opaque(self):
        assert pp.has_real_alpha(Image.new("RGBA", (32, 32), (1, 2, 3, 255))) == False

    def test_alpha_has_real_alpha_rgb_mode(self):
        assert pp.has_real_alpha(Image.new("RGB", (32, 32))) == False

    def test_alpha_has_real_alpha_transparent(self):
        assert pp.has_real_alpha(house_image()) == True

    def test_alpha_bbox_empty(self):
        assert pp.alpha_bbox(Image.new("RGBA", (16, 16))) is None

    def test_alpha_bbox_exclusive_right_bottom(self):
        img = Image.new("RGBA", (16, 16))
        img.putpixel((3, 5), (255, 255, 255, 255))
        assert pp.alpha_bbox(img) == (3, 5, 4, 6)

    def test_alpha_edges_touched_full_frame(self):
        assert pp.edges_touched(Image.new("RGBA", (32, 32), (9, 9, 9, 255))) == 4

    def test_alpha_edges_touched_centered_object(self):
        assert pp.edges_touched(house_image()) == 0

    def test_alpha_clean_alpha_removes_faint_halo(self):
        img = Image.new("RGBA", (8, 8), (200, 200, 200, 3))
        assert pp.alpha_bbox(pp.clean_alpha(img), threshold=1) is None


class Test_Color_Transforms:
    def test_color_hsv_roundtrip_exact_values(self):
        rgb = np.array([[1.0, 0.0, 0.0], [0.5, 0.25, 0.25], [0.0, 0.5, 1.0], [0.25, 0.25, 0.25]])
        back = pp.hsv_to_rgb(pp.rgb_to_hsv(rgb))
        assert float(np.abs(back - rgb).max()) < 1e-9

    def test_color_rgb_to_hsv_pure_red(self):
        h, s, v = pp.rgb_to_hsv(np.array([1.0, 0.0, 0.0]))
        assert abs(h - 0.0) < 1e-9
        assert abs(s - 1.0) < 1e-9
        assert abs(v - 1.0) < 1e-9

    def test_color_normalize_roof_red_orange_red_roof(self, red, artifact_writer):
        img = house_image()
        out, fraction = pp.normalize_roof_red(img, red)
        artifact_writer.add(img, layer="before")
        artifact_writer.add(out, layer="after")
        r, g, b, _ = out.getpixel((200, 200))
        assert r == 190
        assert g == b
        assert abs(g - 28) <= 1
        assert fraction > 0

    def test_color_normalize_roof_red_keeps_brown_wall(self, red):
        out, _ = pp.normalize_roof_red(house_image(), red)
        assert out.getpixel((105, 125)) == (128, 112, 92, 255)

    def test_color_normalize_roof_red_makes_roof_recolorable(self, red):
        before = pp.recolorable_fraction(house_image(roof=(190, 90, 40, 255)), red)
        out, _ = pp.normalize_roof_red(house_image(roof=(190, 90, 40, 255)), red)
        assert before < 1e-9
        assert pp.recolorable_fraction(out, red) > 0.3

    def test_color_normalize_roof_red_is_independent_copy(self, red):
        img = house_image()
        pp.normalize_roof_red(img, red)
        assert img.getpixel((200, 200)) == (190, 45, 30, 255)

    def test_color_suppress_red_leaves_nothing_recolorable(self, red, artifact_writer):
        img = house_image(roof=(200, 20, 20, 255))
        out, fraction = pp.suppress_red(img, red)
        artifact_writer.add(img, layer="before")
        artifact_writer.add(out, layer="after")
        assert fraction > 0
        assert pp.recolorable_fraction(out, red) < 1e-9

    def test_color_suppress_red_no_red_present(self, red):
        img = house_image(roof=(150, 150, 150, 255))
        out, fraction = pp.suppress_red(img, red)
        assert fraction < 1e-9
        assert np.array_equal(np.asarray(out), np.asarray(img)) == True

    def test_color_recolorable_fraction_empty_image(self, red):
        assert pp.recolorable_fraction(Image.new("RGBA", (8, 8)), red) < 1e-9


class Test_Shadow_Operations:
    def _square(self) -> Image.Image:
        return pp.place_centered(Image.new("RGBA", (100, 100), (120, 100, 80, 255)), side=390, canvas=512)

    def test_shadow_add_shadow_bottom_right(self, shadow, artifact_writer):
        img = self._square()
        out = pp.add_shadow(img, 390, shadow)
        artifact_writer.add(img, layer="before")
        artifact_writer.add(out, layer="after")
        before_a = np.asarray(img.getchannel("A"))
        after_a = np.asarray(out.getchannel("A"))
        ys, xs = np.nonzero((before_a == 0) & (after_a > 0))
        assert xs.mean() - 256 > 0
        assert ys.mean() - 256 > 0

    def test_shadow_add_shadow_within_ten_percent(self, shadow):
        img = self._square()
        out = pp.add_shadow(img, 390, shadow)
        _, _, right_before, bottom_before = pp.alpha_bbox(img)
        _, _, right_after, bottom_after = pp.alpha_bbox(out, threshold=24)
        assert right_after - right_before <= 0.1 * 390
        assert bottom_after - bottom_before <= 0.1 * 390

    def test_shadow_add_shadow_keeps_object_pixels(self, shadow):
        img = self._square()
        out = pp.add_shadow(img, 390, shadow)
        assert out.getpixel((256, 256)) == img.getpixel((256, 256))

    def test_shadow_extent_zero_blur(self):
        assert abs(ShadowSettings(offset=0.05, blur=0.0).extent - 0.05) < 1e-9


class Test_Texture_Transforms:
    def _gradient(self) -> Image.Image:
        x = np.tile(np.linspace(0, 255, 256), (256, 1))
        arr = np.stack([x, x.T, np.full_like(x, 128)], axis=-1).astype(np.uint8)
        return Image.fromarray(arr, "RGB")

    def test_texture_seam_ratio_gradient_has_seam(self):
        assert pp.seam_ratio(self._gradient()) > 50

    def test_texture_make_seamless_gradient(self, artifact_writer):
        img = self._gradient()
        out = pp.make_seamless(img)
        artifact_writer.add(img, layer="before")
        tiled = Image.new("RGB", (512, 512))
        for dx in (0, 256):
            for dy in (0, 256):
                tiled.paste(out, (dx, dy))
        artifact_writer.add(tiled, layer="after_tiled_2x2")
        assert out.size == img.size
        assert pp.seam_ratio(out) < 2.0

    def test_texture_center_square_landscape(self):
        assert pp.center_square(Image.new("RGB", (300, 200))).size == (200, 200)

    def test_texture_process_texture_output_size(self):
        spec = make_spec(kind="texture", canvas=128, shadow=False)
        result = pp.process_texture(self._gradient(), spec)
        assert result.image.size == (128, 128)
        assert result.image.mode == "RGB"


class Test_ProcessObject_Operations:
    def test_process_object_transparent_house(self, scale, shadow, red, artifact_writer):
        spec = make_spec(red_mode="tetto")
        raw = house_image()
        result = pp.process_object(raw, spec, scale, shadow, red)
        artifact_writer.add(raw, layer="before")
        artifact_writer.add(result.image, layer="after")
        assert result.image.size == (512, 512)
        assert result.warnings == []
        assert "scontorno" not in result.info

    def test_process_object_opaque_without_removal(self, scale, shadow, red):
        raw = house_image(background=(70, 110, 60, 255))
        with pytest.raises(pp.ProcessingError):
            pp.process_object(raw, make_spec(), scale, shadow, red, background_removal="mai")

    def test_process_object_opaque_uses_removal(self, scale, shadow, red, monkeypatch):
        def fake_removal(img, model_name):
            arr = np.array(img)
            arr[(arr[..., 0] == 70) & (arr[..., 1] == 110)] = 0
            return Image.fromarray(arr, "RGBA")

        monkeypatch.setattr(pp, "remove_background", fake_removal)
        raw = house_image(background=(70, 110, 60, 255))
        result = pp.process_object(raw, make_spec(), scale, shadow, red, rembg_model="finto")
        assert result.info["scontorno"] == "finto"
        assert result.warnings == []

    def test_process_object_leftover_background_warns(self, scale, shadow, red, monkeypatch):
        monkeypatch.setattr(pp, "remove_background", lambda img, model_name: img)
        raw = house_image(background=(70, 110, 60, 255))
        raw.putpixel((0, 0), (0, 0, 0, 0))
        result = pp.process_object(raw, make_spec(), scale, shadow, red, background_removal="sempre")
        assert any("bordi" in w for w in result.warnings) == True

    def test_process_object_empty_image(self, scale, shadow, red):
        with pytest.raises(pp.ProcessingError):
            pp.process_object(Image.new("RGBA", (64, 64)), make_spec(), scale, shadow, red)

    def test_process_object_forbidden_red_removed(self, scale, shadow, red):
        spec = make_spec(red_mode="vietato")
        result = pp.process_object(house_image(roof=(200, 20, 20, 255)), spec, scale, shadow, red)
        assert result.info["ricolorabile"] < 1e-9
        assert result.warnings == []

    def test_process_object_roof_missing_warns(self, scale, shadow, red):
        spec = make_spec(red_mode="tetto")
        result = pp.process_object(house_image(roof=(140, 140, 140, 255)), spec, scale, shadow, red)
        assert any("tetto" in w for w in result.warnings) == True


class Test_Validate_Predicates:
    def test_validate_object_margin_invaded(self, scale, red):
        sprite = Image.new("RGBA", (100, 100))
        sprite.paste((90, 90, 90, 255), (0, 10, 60, 90))
        warnings = pp.validate_object(sprite, make_spec(canvas=100), scale, red)
        assert any("margine" in w for w in warnings) == True

    def test_validate_object_wrong_proportions(self, scale, red):
        sprite = pp.place_centered(Image.new("RGBA", (50, 50), (90, 90, 90, 255)), 60, 100)
        spec = make_spec(canvas=100, size_m=(3.0, 1.5))
        warnings = pp.validate_object(sprite, spec, scale, red, obj_size=(50, 50))
        assert any("proporzioni" in w for w in warnings) == True

    def test_validate_object_proportions_rotated(self, scale, red):
        sprite = pp.place_centered(Image.new("RGBA", (30, 60), (90, 90, 90, 255)), 60, 100)
        spec = make_spec(canvas=100, size_m=(3.0, 1.5))
        warnings = pp.validate_object(sprite, spec, scale, red, obj_size=(30, 60))
        assert any("proporzioni" in w for w in warnings) == False

    def test_validate_object_margin_tolerance_custom_scale(self, red):
        sprite = pp.place_centered(Image.new("RGBA", (50, 50), (90, 90, 90, 255)), 98, 100)
        warnings = pp.validate_object(sprite, make_spec(canvas=100), ScaleSettings(margin=0.0), red)
        assert any("margine" in w for w in warnings) == False


class Test_SavePng_Operations:
    def test_save_png_signature(self, tmp_path):
        path = tmp_path / "sub" / "nm_x.png"
        pp.save_png(house_image(), path)
        assert path.read_bytes()[:8] == pp.PNG_SIGNATURE
