from __future__ import annotations

import base64
import io
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml
from PIL import Image

from conftest import house_image, make_spec
from spritebatch.backends import (
    ComfyUIBackend,
    FakeBackend,
    GenerationError,
    OpenAIBackend,
    fill_placeholders,
)
from spritebatch.catalog import parse_catalog
from spritebatch.cli import main
from spritebatch.pack import build_pack, resolve_pack_id
from spritebatch.pipeline import Workspace, generate_one, process_all
from spritebatch.postprocess import PNG_SIGNATURE


def png_bytes(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


class BadRequest(Exception):
    status_code = 400


class FakeImages:
    def __init__(self, reject_transparent: bool = False, fail: Exception | None = None) -> None:
        self.calls: list[tuple[str, dict]] = []
        self.reject_transparent = reject_transparent
        self.fail = fail

    def _respond(self, kind: str, kwargs: dict):
        self.calls.append((kind, kwargs))
        if self.fail:
            raise self.fail
        if self.reject_transparent and kwargs["background"] == "transparent":
            raise BadRequest("Invalid value for 'background': transparent is not supported")
        data = [SimpleNamespace(b64_json=base64.b64encode(png_bytes(house_image(64, (10, 10, 50, 50)))).decode())
                for _ in range(kwargs["n"])]
        return SimpleNamespace(data=data)

    def generate(self, **kwargs):
        return self._respond("generate", kwargs)

    def edit(self, **kwargs):
        return self._respond("edit", kwargs)


def openai_backend(images: FakeImages) -> OpenAIBackend:
    return OpenAIBackend("gpt-image-2", "1024x1024", "high", client=SimpleNamespace(images=images))


class Test_OpenAIBackend_Operations:
    def test_openai_generate_transparent_png(self):
        images = FakeImages()
        out = openai_backend(images).generate("p", 2, [], transparent=True, seed=0)
        kind, kwargs = images.calls[0]
        assert kind == "generate"
        assert kwargs["background"] == "transparent"
        assert kwargs["output_format"] == "png"
        assert len(out) == 2
        assert out[0][:8] == PNG_SIGNATURE

    def test_openai_generate_texture_opaque(self):
        images = FakeImages()
        openai_backend(images).generate("p", 1, [], transparent=False, seed=0)
        assert images.calls[0][1]["background"] == "opaque"

    def test_openai_generate_with_references_uses_edit(self, tmp_path):
        ref = tmp_path / "rif.png"
        house_image(32, (4, 4, 28, 28)).save(ref)
        images = FakeImages()
        openai_backend(images).generate("p", 1, [ref], transparent=True, seed=0)
        kind, kwargs = images.calls[0]
        assert kind == "edit"
        assert kwargs["image"][0][0] == "rif.png"

    def test_openai_generate_transparency_rejected_falls_back(self):
        images = FakeImages(reject_transparent=True)
        backend = openai_backend(images)
        out = backend.generate("p", 1, [], transparent=True, seed=0)
        backend.generate("p", 1, [], transparent=True, seed=0)
        backgrounds = [kwargs["background"] for _, kwargs in images.calls]
        assert backgrounds == ["transparent", "opaque", "opaque"]
        assert len(out) == 1

    def test_openai_generate_other_error(self):
        images = FakeImages(fail=RuntimeError("rate limit"))
        with pytest.raises(GenerationError):
            openai_backend(images).generate("p", 1, [], transparent=True, seed=0)


class Test_ComfyUIBackend_Transforms:
    def test_comfyui_fill_placeholders_seed_and_prompt(self):
        graph = {"3": {"inputs": {"seed": "%SEED%", "steps": 20}}, "6": {"inputs": {"text": "style, %PROMPT%"}}}
        out = fill_placeholders(graph, "a tavern", 42)
        assert out["3"]["inputs"]["seed"] == 42
        assert out["6"]["inputs"]["text"] == "style, a tavern"

    def test_comfyui_fill_placeholders_is_independent_copy(self):
        graph = {"6": {"inputs": {"text": "%PROMPT%"}}}
        fill_placeholders(graph, "x", 1)
        assert graph["6"]["inputs"]["text"] == "%PROMPT%"

    def test_comfyui_construction_without_placeholder(self, tmp_path):
        wf = tmp_path / "wf.json"
        wf.write_text(json.dumps({"6": {"inputs": {"text": "fixed"}}}))
        with pytest.raises(GenerationError):
            ComfyUIBackend("http://localhost:8188", wf)


class Test_Pipeline_Operations:
    def test_pipeline_generate_one_writes_candidates(self, tmp_path):
        ws = Workspace(tmp_path)
        spec = make_spec(red_mode="tetto")
        assert generate_one(spec, FakeBackend(size=128), ws, 3, []) == "generato"
        assert [p.name for p in ws.candidates(spec)] == ["c1.png", "c2.png", "c3.png"]
        assert "brick red" in (ws.raw_dir(spec) / "prompt.txt").read_text()

    def test_pipeline_generate_one_skips_existing(self, tmp_path):
        ws = Workspace(tmp_path)
        spec = make_spec()
        generate_one(spec, FakeBackend(size=64), ws, 1, [])
        assert generate_one(spec, FakeBackend(size=64), ws, 1, []) == "saltato"

    def test_pipeline_generate_one_force_replaces_old_candidates(self, tmp_path):
        ws = Workspace(tmp_path)
        spec = make_spec()
        generate_one(spec, FakeBackend(size=64), ws, 3, [])
        generate_one(spec, FakeBackend(size=64), ws, 1, [], force=True)
        assert len(ws.candidates(spec)) == 1

    def test_pipeline_candidates_numeric_order(self, tmp_path):
        ws = Workspace(tmp_path)
        spec = make_spec()
        folder = ws.raw_dir(spec)
        folder.mkdir(parents=True)
        for k in (10, 2, 1):
            (folder / f"c{k}.png").write_bytes(b"")
        assert [p.name for p in ws.candidates(spec)] == ["c1.png", "c2.png", "c10.png"]

    def test_pipeline_process_all_uses_choice(self, tmp_path):
        data = {
            "categorie": {"C3": {"canvas": 128, "rosso": "libero"}},
            "sprite": [{"nome": "taverna", "categoria": "C3", "soggetto": "Tavern"}],
        }
        catalog = parse_catalog(data)
        spec = catalog.sprites[0]
        ws = Workspace(tmp_path)
        folder = ws.raw_dir(spec)
        folder.mkdir(parents=True)
        house_image(200, (40, 60, 160, 140)).save(folder / "c1.png")
        house_image(200, (60, 20, 140, 180)).save(folder / "c2.png")
        ws.choices_file.write_text(yaml.safe_dump({"nm_taverna": 2}))
        report = process_all(catalog, [spec], ws)
        assert report["nm_taverna"]["sorgente"] == "c2.png"
        assert (ws.processed / "nm_taverna.png").exists() == True

    def test_pipeline_process_all_missing_candidate(self, tmp_path):
        catalog = parse_catalog({
            "categorie": {"C3": {"canvas": 128}},
            "sprite": [{"nome": "taverna", "categoria": "C3", "soggetto": "Tavern"}],
        })
        report = process_all(catalog, list(catalog.sprites), Workspace(tmp_path))
        assert report["nm_taverna"]["stato"] == "mancante"


class Test_Pack_Operations:
    def test_pack_build_texture_in_both_folders(self, tmp_path):
        catalog = parse_catalog({
            "pacchetto": {"cartella": "Pack", "id": "abcd1234"},
            "categorie": {"C7": {"canvas": 64, "tipo": "texture",
                                 "cartelle": ["textures/terrain", "textures/patterns/normal"]}},
            "sprite": [{"nome": "prato", "categoria": "C7", "soggetto": "Grass"}],
        })
        processed = tmp_path / "elaborati"
        processed.mkdir()
        Image.new("RGB", (64, 64), (90, 120, 70)).save(processed / "nm_prato.png")
        root, missing = build_pack(catalog, list(catalog.sprites), processed, tmp_path / "dist", tmp_path)
        assert missing == []
        assert (root / "textures/terrain/nm_prato.png").exists() == True
        assert (root / "textures/patterns/normal/nm_prato.png").exists() == True
        meta = json.loads((root / "pack.json").read_text())
        assert meta["id"] == "abcd1234"

    def test_pack_resolve_pack_id_persisted(self, tmp_path):
        catalog = parse_catalog({"categorie": {"C3": {"canvas": 64}},
                                 "sprite": [{"nome": "a", "categoria": "C3", "soggetto": "A"}]})
        first = resolve_pack_id(catalog, tmp_path)
        second = resolve_pack_id(catalog, tmp_path)
        assert len(first) == 8
        assert first == second


class Test_Cli_Operations:
    def test_cli_tutto_fake_backend_end_to_end(self, tmp_path):
        catalog_path = Path(__file__).parent.parent / "catalogo.yaml"
        work, dist = tmp_path / "lavoro", tmp_path / "dist"
        code = main([
            "--catalogo", str(catalog_path), "--lavoro", str(work),
            "tutto", "--backend", "finto", "--solo", "casa_01,carro,faro,prato", "--dist", str(dist),
        ])
        assert code == 0
        root = dist / "NovaMistralisCitta"
        carro = Image.open(root / "textures/objects/nm_carro.png")
        assert carro.mode == "RGBA"
        assert carro.size == (672, 672)
        assert (root / "textures/patterns/normal/nm_prato.png").read_bytes()[:8] == PNG_SIGNATURE
        assert (root / "preview.png").exists() == True

    def test_cli_unknown_sprite_exit_code(self, tmp_path):
        catalog_path = Path(__file__).parent.parent / "catalogo.yaml"
        code = main(["--catalogo", str(catalog_path), "--lavoro", str(tmp_path), "lista", "--solo", "drago"])
        assert code == 2

    def test_cli_riferimenti_copies_chosen_anchor(self, tmp_path):
        catalog_path = Path(__file__).parent.parent / "catalogo.yaml"
        work, refs = tmp_path / "lavoro", tmp_path / "riferimenti"
        base = ["--catalogo", str(catalog_path), "--lavoro", str(work)]
        assert main(base + ["genera", "--backend", "finto", "--ancore", "--candidati", "2"]) == 0
        (work / "scelte.yaml").write_text("nm_taverna: 2\n")
        assert main(base + ["riferimenti", "--destinazione", str(refs)]) == 0
        chosen = (work / "grezzi" / "nm_taverna" / "c2.png").read_bytes()
        assert (refs / "nm_taverna.png").read_bytes() == chosen
        assert len(list(refs.glob("*.png"))) == 4
