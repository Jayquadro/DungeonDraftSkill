from __future__ import annotations

import re
from pathlib import Path

import pytest

from spritebatch.catalog import CatalogError, load_catalog, parse_catalog

CATALOG_PATH = Path(__file__).parent.parent / "catalogo.yaml"


def base_data(**extra):
    data = {
        "categorie": {
            "C3": {"canvas": 512, "scala": "canvas", "rosso": "tetto"},
            "C4": {"canvas": 256, "scala": "reale", "rosso": "libero"},
            "C7": {"canvas": 1024, "tipo": "texture", "cartelle": ["textures/terrain", "textures/patterns/normal"]},
        },
        "sprite": [
            {"nome": "taverna", "categoria": "C3", "soggetto": "Tavern"},
            {"nome": "carro", "categoria": "C4", "dimensioni_m": [3, 1.5], "soggetto": "Cart"},
        ],
    }
    data.update(extra)
    return data


class Test_Catalog_Construction:
    def test_catalog_parse_minimal(self):
        catalog = parse_catalog(base_data())
        assert len(catalog.sprites) == 2
        assert catalog.sprites[0].filename == "nm_taverna.png"
        assert catalog.sprites[0].red_mode == "tetto"

    def test_catalog_parse_entry_overrides_category(self):
        data = base_data()
        data["sprite"][0]["rosso"] = "vietato"
        catalog = parse_catalog(data)
        assert catalog.sprites[0].red_mode == "vietato"
        assert catalog.sprites[0].canvas == 512

    def test_catalog_parse_variants_zero_padded(self):
        data = base_data()
        data["sprite"] = [{"nome": "casa_{i:02d}", "categoria": "C3", "soggetto": "House",
                           "varianti": ["a", "b", "c"]}]
        names = [s.stem for s in parse_catalog(data).sprites]
        assert names == ["nm_casa_01", "nm_casa_02", "nm_casa_03"]

    def test_catalog_parse_variants_subject_joined(self):
        data = base_data()
        data["sprite"] = [{"nome": "statua_{i}", "categoria": "C3", "soggetto": "Statue.",
                           "varianti": ["a warrior"]}]
        assert parse_catalog(data).sprites[0].subject == "Statue. a warrior"

    def test_catalog_parse_variant_dict_overrides_size(self):
        data = base_data()
        data["sprite"] = [{"nome": "albero_{i}", "categoria": "C4", "soggetto": "Tree", "dimensioni_m": [5, 5],
                           "varianti": ["broad", {"soggetto": "narrow", "dimensioni_m": [4, 4]}]}]
        sprites = parse_catalog(data).sprites
        assert abs(sprites[0].max_size_m - 5.0) < 1e-9
        assert abs(sprites[1].max_size_m - 4.0) < 1e-9

    def test_catalog_parse_texture_defaults(self):
        data = base_data()
        data["sprite"].append({"nome": "prato", "categoria": "C7", "soggetto": "Grass"})
        texture = parse_catalog(data).sprites[-1]
        assert texture.kind == "texture"
        assert texture.shadow == False
        assert texture.folders == ("textures/terrain", "textures/patterns/normal")

    def test_catalog_parse_duplicate_name(self):
        data = base_data()
        data["sprite"].append({"nome": "taverna", "categoria": "C3", "soggetto": "Again"})
        with pytest.raises(CatalogError):
            parse_catalog(data)

    def test_catalog_parse_uppercase_name(self):
        data = base_data()
        data["sprite"][0]["nome"] = "Taverna"
        with pytest.raises(CatalogError):
            parse_catalog(data)

    def test_catalog_parse_non_ascii_name(self):
        data = base_data()
        data["sprite"][0]["nome"] = "città"
        with pytest.raises(CatalogError):
            parse_catalog(data)

    def test_catalog_parse_real_scale_without_size(self):
        data = base_data()
        del data["sprite"][1]["dimensioni_m"]
        with pytest.raises(CatalogError):
            parse_catalog(data)

    def test_catalog_parse_unknown_anchor(self):
        data = base_data(generazione={"ancore": ["nm_inesistente"]})
        with pytest.raises(CatalogError):
            parse_catalog(data)

    def test_catalog_parse_variants_without_placeholder(self):
        data = base_data()
        data["sprite"] = [{"nome": "casa", "categoria": "C3", "soggetto": "House", "varianti": ["a", "b"]}]
        with pytest.raises(CatalogError):
            parse_catalog(data)

    def test_catalog_load_project_file(self):
        catalog = load_catalog(CATALOG_PATH)
        pattern = re.compile(r"^nm_[a-z0-9_]+\.png$")
        assert len(catalog.sprites) == 85
        assert all(pattern.match(s.filename) for s in catalog.sprites) == True
        assert len(catalog.settings.generation.anchors) == 4


class Test_Catalog_Operations:
    def test_catalog_select_only_without_prefix(self):
        catalog = parse_catalog(base_data())
        assert [s.stem for s in catalog.select(only=["carro"])] == ["nm_carro"]

    def test_catalog_select_only_with_extension(self):
        catalog = parse_catalog(base_data())
        assert [s.stem for s in catalog.select(only=["nm_carro.png"])] == ["nm_carro"]

    def test_catalog_select_unknown_name(self):
        catalog = parse_catalog(base_data())
        with pytest.raises(CatalogError):
            catalog.select(only=["mulino"])

    def test_catalog_select_category_case_insensitive(self):
        catalog = parse_catalog(base_data())
        assert [s.stem for s in catalog.select(categories=["c4"])] == ["nm_carro"]

    def test_catalog_select_anchors(self):
        catalog = parse_catalog(base_data(generazione={"ancore": ["taverna"]}))
        assert [s.stem for s in catalog.select(anchors=True)] == ["nm_taverna"]

    def test_catalog_select_is_independent_copy(self):
        catalog = parse_catalog(base_data())
        chosen = catalog.select()
        chosen.clear()
        assert len(catalog.sprites) == 2
