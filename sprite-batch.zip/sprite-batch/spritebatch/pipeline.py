"""Fasi della pipeline: generazione dei candidati ed elaborazione degli sprite."""

from __future__ import annotations

import json
import logging
import secrets
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from pathlib import Path

import yaml

from .backends import Backend, GenerationError
from .catalog import Catalog, SpriteSpec
from .postprocess import (
    ProcessingError,
    load_rgba,
    process_object,
    process_texture,
    save_png,
)
from .prompts import build_prompt

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class Workspace:
    root: Path

    @property
    def raw(self) -> Path:
        return self.root / "grezzi"

    @property
    def processed(self) -> Path:
        return self.root / "elaborati"

    @property
    def choices_file(self) -> Path:
        return self.root / "scelte.yaml"

    @property
    def report_file(self) -> Path:
        return self.root / "rapporto.json"

    def raw_dir(self, spec: SpriteSpec) -> Path:
        return self.raw / spec.stem

    def candidates(self, spec: SpriteSpec) -> list[Path]:
        folder = self.raw_dir(spec)
        if not folder.exists():
            return []
        return sorted(folder.glob("c*.png"), key=lambda p: int(p.stem[1:]))


def list_references(folder: Path | None) -> list[Path]:
    if folder is None:
        return []
    if not folder.is_dir():
        raise FileNotFoundError(f"cartella riferimenti inesistente: {folder}")
    return sorted(p for p in folder.iterdir() if p.suffix.lower() == ".png")


# --------------------------------------------------------------------------- #
# Generazione
# --------------------------------------------------------------------------- #


def generate_one(
    spec: SpriteSpec,
    backend: Backend,
    ws: Workspace,
    candidates: int,
    references: list[Path],
    force: bool = False,
    seed: int = 0,
) -> str:
    """Genera i candidati di uno sprite. Restituisce 'generato' o 'saltato'."""
    folder = ws.raw_dir(spec)
    existing = ws.candidates(spec)
    if existing and not force:
        return "saltato"

    refs = references if (spec.kind == "oggetto" and backend.supports_references) else []
    prompt = build_prompt(spec, has_references=bool(refs))
    images = backend.generate(prompt, candidates, refs, transparent=spec.kind == "oggetto", seed=seed)

    folder.mkdir(parents=True, exist_ok=True)
    for old in existing:
        old.unlink()
    for k, data in enumerate(images, start=1):
        (folder / f"c{k}.png").write_bytes(data)
    (folder / "prompt.txt").write_text(f"# backend: {backend.name}  seed: {seed}\n\n{prompt}", encoding="utf-8")
    return "generato"


def generate_all(
    specs: list[SpriteSpec],
    backend: Backend,
    ws: Workspace,
    candidates: int,
    references: list[Path],
    parallel: int = 1,
    force: bool = False,
) -> dict[str, str]:
    results: dict[str, str] = {}

    def task(spec: SpriteSpec) -> tuple[str, str]:
        try:
            seed = secrets.randbelow(2**31)
            return spec.stem, generate_one(spec, backend, ws, candidates, references, force, seed)
        except (GenerationError, OSError) as exc:
            log.error("%s: generazione fallita: %s", spec.stem, exc)
            return spec.stem, f"errore: {exc}"

    with ThreadPoolExecutor(max_workers=max(1, parallel)) as pool:
        futures = [pool.submit(task, s) for s in specs]
        for done, fut in enumerate(as_completed(futures), start=1):
            stem, outcome = fut.result()
            results[stem] = outcome
            log.info("[%d/%d] %s: %s", done, len(specs), stem, outcome)
    return results


# --------------------------------------------------------------------------- #
# Elaborazione
# --------------------------------------------------------------------------- #


def load_choices(ws: Workspace) -> dict[str, int]:
    if not ws.choices_file.exists():
        return {}
    data = yaml.safe_load(ws.choices_file.read_text(encoding="utf-8")) or {}
    return {str(k).removesuffix(".png"): int(v) for k, v in data.items()}


def process_all(
    catalog: Catalog,
    specs: list[SpriteSpec],
    ws: Workspace,
    background_removal: str = "auto",
    rembg_model: str = "birefnet-general",
    seamless: bool = True,
) -> dict[str, dict]:
    settings = catalog.settings
    choices = load_choices(ws)
    report: dict[str, dict] = {}
    if ws.report_file.exists():
        report = json.loads(ws.report_file.read_text(encoding="utf-8"))

    for spec in specs:
        candidates = ws.candidates(spec)
        if not candidates:
            report[spec.stem] = {"stato": "mancante", "avvisi": ["nessun candidato generato"]}
            continue
        index = choices.get(spec.stem, 1)
        if not 1 <= index <= len(candidates):
            report[spec.stem] = {"stato": "errore", "avvisi": [f"scelta c{index} inesistente"]}
            continue
        source = candidates[index - 1]

        try:
            raw = load_rgba(source)
            if spec.kind == "texture":
                result = process_texture(raw, spec, seamless=seamless)
            else:
                result = process_object(
                    raw, spec, settings.scale, settings.shadow, settings.red,
                    background_removal=background_removal, rembg_model=rembg_model,
                )
            save_png(result.image, ws.processed / spec.filename)
        except (ProcessingError, OSError) as exc:
            report[spec.stem] = {"stato": "errore", "sorgente": source.name, "avvisi": [str(exc)]}
            log.error("%s: %s", spec.stem, exc)
            continue

        report[spec.stem] = {
            "stato": "avvisi" if result.warnings else "ok",
            "sorgente": source.name,
            "avvisi": result.warnings,
            **result.info,
        }
        level = logging.WARNING if result.warnings else logging.INFO
        log.log(level, "%s (%s): %s", spec.stem, source.name, "; ".join(result.warnings) or "ok")

    ws.root.mkdir(parents=True, exist_ok=True)
    ws.report_file.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report
