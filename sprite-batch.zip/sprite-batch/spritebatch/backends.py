"""Backend di generazione immagini.

Ogni backend espone `generate(prompt, n, references, transparent, seed) -> list[bytes]`
e restituisce i byte delle immagini (PNG). Il resto della pipeline non sa chi le ha prodotte.
"""

from __future__ import annotations

import base64
import copy
import hashlib
import io
import json
import logging
import random
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Protocol

import numpy as np
from PIL import Image, ImageDraw

log = logging.getLogger(__name__)


class GenerationError(RuntimeError):
    """La generazione di un'immagine è fallita."""


class Backend(Protocol):
    name: str
    supports_references: bool

    def generate(
        self,
        prompt: str,
        n: int,
        references: list[Path],
        transparent: bool,
        seed: int,
    ) -> list[bytes]: ...


# --------------------------------------------------------------------------- #
# OpenAI
# --------------------------------------------------------------------------- #


class OpenAIBackend:
    """gpt-image-* via API ufficiale. Usa images.edit quando ci sono riferimenti."""

    name = "openai"
    supports_references = True
    MAX_REFERENCES = 16

    def __init__(self, model: str, size: str, quality: str, client: Any = None) -> None:
        if client is None:
            try:
                from openai import OpenAI
            except ImportError as exc:  # pragma: no cover - dipende dall'ambiente
                raise GenerationError("pacchetto openai non installato: pip install openai") from exc
            client = OpenAI(max_retries=4)  # legge OPENAI_API_KEY dall'ambiente
        self.client = client
        self.model = model
        self.size = size
        self.quality = quality
        self._transparency_ok = True
        self._lock = threading.Lock()

    def generate(
        self,
        prompt: str,
        n: int,
        references: list[Path],
        transparent: bool,
        seed: int,
    ) -> list[bytes]:
        refs = references[: self.MAX_REFERENCES]
        if len(references) > self.MAX_REFERENCES:
            log.warning("uso solo i primi %d riferimenti su %d", self.MAX_REFERENCES, len(references))

        want_alpha = transparent and self._transparency_ok
        try:
            return self._call(prompt, n, refs, "transparent" if want_alpha else "opaque")
        except Exception as exc:  # noqa: BLE001 - l'SDK ha molte classi di errore
            if want_alpha and _is_background_rejection(exc):
                with self._lock:
                    if self._transparency_ok:
                        log.warning(
                            "il modello %s rifiuta background=transparent: passo a sfondo opaco "
                            "e scontorno locale",
                            self.model,
                        )
                    self._transparency_ok = False
                return self._call(prompt, n, refs, "opaque")
            raise GenerationError(str(exc)) from exc

    def _call(self, prompt: str, n: int, refs: list[Path], background: str) -> list[bytes]:
        common = dict(
            model=self.model,
            prompt=prompt,
            n=n,
            size=self.size,
            quality=self.quality,
            background=background,
            output_format="png",
        )
        if refs:
            files = [(p.name, p.read_bytes(), "image/png") for p in refs]
            response = self.client.images.edit(image=files, **common)
        else:
            response = self.client.images.generate(**common)
        images = [base64.b64decode(item.b64_json) for item in response.data if item.b64_json]
        if not images:
            raise GenerationError("risposta senza immagini")
        return images


def _is_background_rejection(exc: Exception) -> bool:
    status = getattr(exc, "status_code", None)
    return status == 400 and "background" in str(exc).lower()


# --------------------------------------------------------------------------- #
# ComfyUI
# --------------------------------------------------------------------------- #


class ComfyUIBackend:
    """Esegue un workflow ComfyUI esportato in formato API.

    Nel JSON del workflow sostituisce questi segnaposto:
      "%PROMPT%"  dentro qualsiasi stringa (es. il testo del nodo CLIPTextEncode)
      "%SEED%"    come valore intero (il campo deve contenere esattamente "%SEED%")
    Tutti i nodi di output (SaveImage) vengono raccolti.
    """

    name = "comfyui"
    supports_references = False

    def __init__(self, url: str, workflow_path: str | Path, timeout_s: float = 900.0) -> None:
        if not workflow_path:
            raise GenerationError("backend comfyui: imposta 'comfyui_workflow' nel catalogo o --workflow")
        self.url = url.rstrip("/")
        self.workflow = json.loads(Path(workflow_path).read_text(encoding="utf-8"))
        if "%PROMPT%" not in json.dumps(self.workflow):
            raise GenerationError("il workflow ComfyUI non contiene il segnaposto %PROMPT%")
        self.timeout_s = timeout_s
        self.client_id = str(uuid.uuid4())

    def generate(
        self,
        prompt: str,
        n: int,
        references: list[Path],
        transparent: bool,
        seed: int,
    ) -> list[bytes]:
        if references:
            log.debug("ComfyUI: riferimenti ignorati (lo stile lo dà la LoRA del workflow)")
        images: list[bytes] = []
        for k in range(n):
            graph = fill_placeholders(copy.deepcopy(self.workflow), prompt, seed + k)
            prompt_id = self._post_json("/prompt", {"prompt": graph, "client_id": self.client_id})["prompt_id"]
            images.extend(self._wait_images(prompt_id))
        if not images:
            raise GenerationError("ComfyUI non ha restituito immagini")
        return images

    def _post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        req = urllib.request.Request(
            self.url + path,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            raise GenerationError(f"ComfyUI {exc.code}: {exc.read().decode('utf-8', 'replace')}") from exc

    def _get(self, path: str) -> bytes:
        with urllib.request.urlopen(self.url + path, timeout=60) as resp:
            return resp.read()

    def _wait_images(self, prompt_id: str) -> list[bytes]:
        deadline = time.monotonic() + self.timeout_s
        while time.monotonic() < deadline:
            history = json.loads(self._get(f"/history/{prompt_id}"))
            entry = history.get(prompt_id)
            if entry:
                status = entry.get("status", {})
                if status.get("status_str") == "error":
                    raise GenerationError(f"ComfyUI: esecuzione fallita ({prompt_id})")
                outputs = entry.get("outputs", {})
                if outputs:
                    return [self._download(img) for node in outputs.values() for img in node.get("images", [])
                            if img.get("type") == "output"]
            time.sleep(1.0)
        raise GenerationError(f"ComfyUI: timeout dopo {self.timeout_s:.0f} s")

    def _download(self, img: dict[str, str]) -> bytes:
        query = urllib.parse.urlencode(
            {"filename": img["filename"], "subfolder": img.get("subfolder", ""), "type": img.get("type", "output")}
        )
        return self._get(f"/view?{query}")


def fill_placeholders(node: Any, prompt: str, seed: int) -> Any:
    if isinstance(node, dict):
        return {k: fill_placeholders(v, prompt, seed) for k, v in node.items()}
    if isinstance(node, list):
        return [fill_placeholders(v, prompt, seed) for v in node]
    if isinstance(node, str):
        if node == "%SEED%":
            return seed
        return node.replace("%PROMPT%", prompt)
    return node


# --------------------------------------------------------------------------- #
# Finto (per provare la pipeline senza spendere)
# --------------------------------------------------------------------------- #


class FakeBackend:
    """Disegna forme segnaposto. `opaque=True` simula un modello senza trasparenza."""

    name = "finto"
    supports_references = True

    def __init__(self, size: int = 1024, opaque: bool = False) -> None:
        self.size = size
        self.opaque = opaque

    def generate(
        self,
        prompt: str,
        n: int,
        references: list[Path],
        transparent: bool,
        seed: int,
    ) -> list[bytes]:
        base = int(hashlib.sha256(prompt.encode("utf-8")).hexdigest()[:8], 16)
        return [self._draw(prompt, transparent, base + seed + k) for k in range(n)]

    def _draw(self, prompt: str, transparent: bool, seed: int) -> bytes:
        rng = random.Random(seed)
        s = self.size
        if not transparent:
            noise = np.random.default_rng(seed).integers(90, 131, size=(s, s), dtype=np.int16)
            arr = np.stack([noise, noise - 20, noise - 45], axis=-1).astype(np.uint8)
            return _png(Image.fromarray(arr, "RGB"))

        bg = (70, 110, 60, 255) if self.opaque else (0, 0, 0, 0)
        img = Image.new("RGBA", (s, s), bg)
        draw = ImageDraw.Draw(img)
        w = rng.randint(int(s * 0.35), int(s * 0.7))
        h = rng.randint(int(s * 0.3), int(s * 0.6))
        x0, y0 = (s - w) // 2, (s - h) // 2
        draw.rectangle((x0, y0, x0 + w, y0 + h), fill=(128, 112, 92, 255))
        inset = max(4, min(w, h) // 10)
        roof = (178, 34, 34, 255) if "brick red" in prompt else (150, 120, 70, 255)
        draw.rectangle((x0 + inset, y0 + inset, x0 + w - inset, y0 + h - inset), fill=roof)
        draw.line((x0 + inset, y0 + h // 2, x0 + w - inset, y0 + h // 2), fill=(90, 20, 20, 255), width=3)
        return _png(img)


def _png(img: Image.Image) -> bytes:
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def make_backend(name: str, settings: Any, **overrides: Any) -> Backend:
    gen = settings.generation
    if name == "openai":
        return OpenAIBackend(
            model=overrides.get("model") or gen.model,
            size=overrides.get("size") or gen.size,
            quality=overrides.get("quality") or gen.quality,
        )
    if name == "comfyui":
        return ComfyUIBackend(
            url=overrides.get("comfyui_url") or gen.comfyui_url,
            workflow_path=overrides.get("workflow") or gen.comfyui_workflow,
        )
    if name == "finto":
        return FakeBackend(opaque=bool(overrides.get("opaque", False)))
    raise GenerationError(f"backend sconosciuto: {name}")
