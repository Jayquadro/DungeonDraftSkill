"""Riga di comando.

    python -m spritebatch lista
    python -m spritebatch prompt nm_taverna
    python -m spritebatch genera --ancore
    python -m spritebatch riferimenti
    python -m spritebatch genera --riferimenti riferimenti/
    python -m spritebatch elabora
    python -m spritebatch pacchetto
    python -m spritebatch tutto --riferimenti riferimenti/
"""

from __future__ import annotations

import argparse
import logging
import shutil
import sys
from pathlib import Path

from .backends import GenerationError, make_backend
from .catalog import Catalog, CatalogError, SpriteSpec, load_catalog
from .pack import build_pack
from .pipeline import Workspace, generate_all, list_references, load_choices, process_all
from .postprocess import target_geometry
from .prompts import build_prompt

log = logging.getLogger("spritebatch")


def _split(values: list[str] | None) -> list[str] | None:
    if not values:
        return None
    return [item for value in values for item in value.split(",") if item.strip()]


def _selection(args: argparse.Namespace, catalog: Catalog) -> list[SpriteSpec]:
    specs = catalog.select(
        only=_split(getattr(args, "solo", None)),
        categories=_split(getattr(args, "categoria", None)),
        anchors=getattr(args, "ancore", False),
    )
    if not specs:
        raise CatalogError("nessuno sprite corrisponde ai filtri")
    return specs


# --------------------------------------------------------------------------- #
# Comandi
# --------------------------------------------------------------------------- #


def cmd_lista(args: argparse.Namespace, catalog: Catalog) -> int:
    s = catalog.settings
    specs = _selection(args, catalog)
    print(f"{'file':<28} {'cat':<4} {'tipo':<8} {'scala':<7} {'rosso':<8} {'oggetto':>8} {'canvas':>7}")
    for spec in specs:
        if spec.kind == "texture":
            side, canvas = "-", spec.canvas
        else:
            side, canvas = target_geometry(spec, s.scale, s.shadow)
        note = f"  (da {spec.canvas})" if canvas != spec.canvas else ""
        print(
            f"{spec.filename:<28} {spec.category:<4} {spec.kind:<8} {spec.scale_mode:<7} "
            f"{spec.red_mode:<8} {side!s:>8} {canvas:>7}{note}"
        )
    print(f"\n{len(specs)} sprite")
    return 0


def cmd_prompt(args: argparse.Namespace, catalog: Catalog) -> int:
    for spec in _selection(args, catalog):
        print(f"===== {spec.filename} =====")
        print(build_prompt(spec, has_references=args.con_riferimenti))
        print()
    return 0


def cmd_genera(args: argparse.Namespace, catalog: Catalog) -> int:
    gen = catalog.settings.generation
    specs = _selection(args, catalog)
    references = list_references(args.riferimenti)
    candidates = args.candidati or gen.candidates
    backend_name = args.backend or gen.backend

    if args.dry_run:
        calls = len(specs)
        print(f"{calls} chiamate a '{backend_name}', {candidates} candidati ciascuna "
              f"({calls * candidates} immagini), {len(references)} riferimenti")
        for spec in specs:
            print(" -", spec.filename)
        return 0

    backend = make_backend(
        backend_name, catalog.settings,
        model=args.modello, size=args.dimensione, quality=args.qualita,
        workflow=args.workflow, opaque=args.finto_opaco,
    )
    ws = Workspace(args.lavoro)
    results = generate_all(
        specs, backend, ws, candidates, references,
        parallel=args.parallelo or gen.parallel, force=args.forza,
    )
    failed = [k for k, v in results.items() if v.startswith("errore")]
    print(f"\ngenerati {sum(v == 'generato' for v in results.values())}, "
          f"saltati {sum(v == 'saltato' for v in results.values())}, errori {len(failed)}")
    return 1 if failed else 0


def cmd_elabora(args: argparse.Namespace, catalog: Catalog) -> int:
    specs = _selection(args, catalog)
    report = process_all(
        catalog, specs, Workspace(args.lavoro),
        background_removal=args.scontorno, rembg_model=args.modello_scontorno,
        seamless=not args.no_piastrella,
    )
    selected = {s.stem for s in specs}
    rows = {k: v for k, v in report.items() if k in selected}
    ok = sum(v["stato"] == "ok" for v in rows.values())
    warn = sum(v["stato"] == "avvisi" for v in rows.values())
    bad = sum(v["stato"] in ("errore", "mancante") for v in rows.values())
    print(f"\nok {ok}, con avvisi {warn}, errori o mancanti {bad}  ->  {Workspace(args.lavoro).report_file}")
    return 1 if bad else 0


def cmd_riferimenti(args: argparse.Namespace, catalog: Catalog) -> int:
    """Copia i candidati grezzi scelti (senza ombra aggiunta) nella cartella dei riferimenti."""
    if not (args.solo or args.categoria):
        args.ancore = True
    ws = Workspace(args.lavoro)
    choices = load_choices(ws)
    args.destinazione.mkdir(parents=True, exist_ok=True)
    missing = 0
    for spec in _selection(args, catalog):
        candidates = ws.candidates(spec)
        index = choices.get(spec.stem, 1)
        if not 1 <= index <= len(candidates):
            log.error("%s: candidato c%d non disponibile", spec.stem, index)
            missing += 1
            continue
        shutil.copyfile(candidates[index - 1], args.destinazione / spec.filename)
        print(f"{spec.filename} <- {candidates[index - 1].name}")
    return 1 if missing else 0


def cmd_pacchetto(args: argparse.Namespace, catalog: Catalog) -> int:
    ws = Workspace(args.lavoro)
    specs = _selection(args, catalog)
    root, missing = build_pack(catalog, specs, ws.processed, args.dist, ws.root)
    print(f"pack in {root}")
    if missing:
        print(f"mancano {len(missing)} sprite elaborati: {', '.join(missing)}")
    return 1 if missing else 0


def cmd_tutto(args: argparse.Namespace, catalog: Catalog) -> int:
    code = cmd_genera(args, catalog)
    if args.dry_run:
        return code
    code = max(code, cmd_elabora(args, catalog))
    return max(code, cmd_pacchetto(args, catalog))


# --------------------------------------------------------------------------- #
# Parser
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="spritebatch", description="Pacchetto sprite Dungeondraft in batch")
    parser.add_argument("--catalogo", type=Path, default=Path("catalogo.yaml"))
    parser.add_argument("--lavoro", type=Path, default=Path("lavoro"))
    parser.add_argument("-v", "--verbose", action="store_true")
    sub = parser.add_subparsers(dest="comando", required=True)

    def filters(p: argparse.ArgumentParser) -> None:
        p.add_argument("--solo", action="append", help="nomi separati da virgola (con o senza nm_)")
        p.add_argument("--categoria", action="append", help="es. C3 oppure C1,C2")
        p.add_argument("--ancore", action="store_true", help="solo gli sprite elencati in generazione.ancore")

    def gen_opts(p: argparse.ArgumentParser) -> None:
        p.add_argument("--backend", choices=("openai", "comfyui", "finto"))
        p.add_argument("--riferimenti", type=Path, help="cartella di PNG da usare come riferimento di stile")
        p.add_argument("--candidati", type=int)
        p.add_argument("--parallelo", type=int)
        p.add_argument("--modello")
        p.add_argument("--dimensione")
        p.add_argument("--qualita")
        p.add_argument("--workflow", help="workflow ComfyUI in formato API")
        p.add_argument("--forza", action="store_true", help="rigenera anche se esistono già candidati")
        p.add_argument("--dry-run", action="store_true", help="mostra cosa verrebbe generato, senza chiamate")
        p.add_argument("--finto-opaco", action="store_true", help=argparse.SUPPRESS)

    def proc_opts(p: argparse.ArgumentParser) -> None:
        p.add_argument("--scontorno", choices=("auto", "sempre", "mai"), default="auto")
        p.add_argument("--modello-scontorno", default="birefnet-general")
        p.add_argument("--no-piastrella", action="store_true", help="non rendere piastrellabili le texture")

    def pack_opts(p: argparse.ArgumentParser) -> None:
        p.add_argument("--dist", type=Path, default=Path("dist"))

    p = sub.add_parser("lista", help="elenca gli sprite con canvas e dimensioni calcolate")
    filters(p)
    p.set_defaults(func=cmd_lista)

    p = sub.add_parser("prompt", help="stampa il prompt che verrebbe inviato")
    filters(p)
    p.add_argument("nomi", nargs="*")
    p.add_argument("--con-riferimenti", action="store_true")
    p.set_defaults(func=cmd_prompt)

    p = sub.add_parser("genera", help="genera i candidati grezzi")
    filters(p)
    gen_opts(p)
    p.set_defaults(func=cmd_genera)

    p = sub.add_parser("elabora", help="post-processing dei candidati scelti")
    filters(p)
    proc_opts(p)
    p.set_defaults(func=cmd_elabora)

    p = sub.add_parser("riferimenti", help="copia i candidati scelti delle ancore come riferimenti di stile")
    filters(p)
    p.add_argument("--destinazione", type=Path, default=Path("riferimenti"))
    p.set_defaults(func=cmd_riferimenti)

    p = sub.add_parser("pacchetto", help="assembla la cartella del pack")
    filters(p)
    pack_opts(p)
    p.set_defaults(func=cmd_pacchetto)

    p = sub.add_parser("tutto", help="genera, elabora e assembla")
    filters(p)
    gen_opts(p)
    proc_opts(p)
    pack_opts(p)
    p.set_defaults(func=cmd_tutto)

    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)-7s %(message)s",
    )
    if args.comando == "prompt" and args.nomi:
        args.solo = (args.solo or []) + args.nomi
    try:
        catalog = load_catalog(args.catalogo)
        return args.func(args, catalog)
    except (CatalogError, GenerationError, FileNotFoundError) as exc:
        log.error("%s", exc)
        return 2


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
