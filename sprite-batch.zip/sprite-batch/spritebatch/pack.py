"""Assemblaggio della cartella del pack pronta per il packer di Dungeondraft."""

from __future__ import annotations

import json
import math
import secrets
import shutil
import string
from pathlib import Path

from PIL import Image, ImageDraw

from .catalog import Catalog, SpriteSpec

ID_ALPHABET = string.ascii_letters + string.digits


def resolve_pack_id(catalog: Catalog, workdir: Path) -> str:
    """Id del pack: dal catalogo, altrimenti generato una volta e salvato in lavoro/."""
    if catalog.settings.pack.id:
        return catalog.settings.pack.id
    id_file = workdir / "pack_id.txt"
    if id_file.exists():
        return id_file.read_text(encoding="utf-8").strip()
    new_id = "".join(secrets.choice(ID_ALPHABET) for _ in range(8))
    id_file.parent.mkdir(parents=True, exist_ok=True)
    id_file.write_text(new_id, encoding="utf-8")
    return new_id


def pack_metadata(catalog: Catalog, pack_id: str) -> dict:
    p = catalog.settings.pack
    red = catalog.settings.red
    return {
        "name": p.name,
        "id": pack_id,
        "version": p.version,
        "author": p.author,
        "custom_color_overrides": {
            "enabled": False,
            "min_redness": red.dd_min_redness,
            "min_saturation": red.dd_min_saturation,
            "red_tolerance": red.dd_red_tolerance,
        },
    }


def build_pack(
    catalog: Catalog,
    specs: list[SpriteSpec],
    processed_dir: Path,
    dist_dir: Path,
    workdir: Path,
) -> tuple[Path, list[str]]:
    """Copia gli sprite elaborati nella struttura del pack. Restituisce (cartella, mancanti)."""
    root = dist_dir / catalog.settings.pack.folder
    missing: list[str] = []
    copied: list[Path] = []

    for spec in specs:
        src = processed_dir / spec.filename
        if not src.exists():
            missing.append(spec.filename)
            continue
        for folder in spec.folders:
            dst = root / folder / spec.filename
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dst)
        if spec.kind == "oggetto":
            copied.append(src)

    meta = pack_metadata(catalog, resolve_pack_id(catalog, workdir))
    root.mkdir(parents=True, exist_ok=True)
    for fname in catalog.settings.pack.metadata_files:
        (root / fname).write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")

    if copied:
        contact_sheet(copied).save(root / "preview.png", format="PNG")
    return root, missing


def contact_sheet(paths: list[Path], cell: int = 160, columns: int = 8) -> Image.Image:
    """Provino di tutti gli sprite su fondo pergamena, per vedere la coerenza d'insieme."""
    columns = min(columns, len(paths))
    rows = math.ceil(len(paths) / columns)
    label_h = 18
    sheet = Image.new("RGBA", (columns * cell, rows * (cell + label_h)), (214, 196, 160, 255))
    draw = ImageDraw.Draw(sheet)
    for i, path in enumerate(paths):
        with Image.open(path) as im:
            thumb = im.convert("RGBA")
            thumb.thumbnail((cell - 8, cell - 8), Image.Resampling.LANCZOS)
        col, row = i % columns, i // columns
        x = col * cell + (cell - thumb.width) // 2
        y = row * (cell + label_h) + (cell - thumb.height) // 2
        sheet.alpha_composite(thumb, (x, y))
        label = path.stem.removeprefix("nm_")[:22]
        draw.text((col * cell + 4, row * (cell + label_h) + cell), label, fill=(60, 45, 30, 255))
    return sheet
