"""Generazione batch del pacchetto sprite "Nova Mistralis Città" per Dungeondraft."""

__version__ = "0.1.0"
