"""Post-processing degli sprite: tutto ciò che il modello non garantisce da solo.

Ordine per gli oggetti:
    scontorno -> pulizia alfa -> ritaglio -> scala -> rossi -> ombra -> validazione
Per le texture:
    ritaglio quadrato -> ridimensionamento -> piastrellabilità
"""

from __future__ import annotations

import io
import math
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

from .catalog import RedSettings, ScaleSettings, ShadowSettings, SpriteSpec

ALPHA_THRESHOLD = 8
PNG_SIGNATURE = b"\x89PNG\r\n\x1a\n"


class ProcessingError(RuntimeError):
    """Lo sprite non può essere elaborato (immagine vuota, scontorno impossibile, ...)."""


@dataclass
class ProcessResult:
    image: Image.Image
    warnings: list[str] = field(default_factory=list)
    info: dict[str, object] = field(default_factory=dict)


# --------------------------------------------------------------------------- #
# Caricamento e trasparenza
# --------------------------------------------------------------------------- #


def load_rgba(source: bytes | str | Path) -> Image.Image:
    if isinstance(source, (bytes, bytearray)):
        img = Image.open(io.BytesIO(source))
    else:
        img = Image.open(source)
    img.load()
    return img.convert("RGBA")


def has_real_alpha(img: Image.Image, min_transparent_fraction: float = 0.01) -> bool:
    """True se l'immagine ha davvero pixel trasparenti (non una scacchiera dipinta)."""
    if img.mode != "RGBA":
        return False
    alpha = np.asarray(img.getchannel("A"))
    return float((alpha < 250).mean()) >= min_transparent_fraction


@lru_cache(maxsize=2)
def _rembg_session(model_name: str):
    try:
        from rembg import new_session
    except ImportError as exc:  # pragma: no cover - dipende dall'ambiente
        raise ProcessingError(
            "serve lo scontorno ma rembg non è installato: pip install \"rembg[cpu]\" "
            "(oppure \"rembg[gpu]\")"
        ) from exc
    return new_session(model_name)


def remove_background(img: Image.Image, model_name: str) -> Image.Image:
    session = _rembg_session(model_name)  # solleva ProcessingError se rembg manca
    from rembg import remove  # import tardivo: dipendenza opzionale

    return remove(img.convert("RGBA"), session=session).convert("RGBA")


def clean_alpha(img: Image.Image, threshold: int = ALPHA_THRESHOLD) -> Image.Image:
    """Azzera i pixel quasi trasparenti: eliminano aloni e rumore dal bounding box."""
    arr = np.array(img.convert("RGBA"))
    faint = arr[..., 3] < threshold
    arr[faint] = 0
    return Image.fromarray(arr, "RGBA")


def alpha_bbox(img: Image.Image, threshold: int = ALPHA_THRESHOLD) -> tuple[int, int, int, int] | None:
    """Bounding box (left, top, right, bottom) esclusivo dei pixel con alfa >= soglia."""
    alpha = np.asarray(img.convert("RGBA").getchannel("A"))
    ys, xs = np.nonzero(alpha >= threshold)
    if xs.size == 0:
        return None
    return int(xs.min()), int(ys.min()), int(xs.max()) + 1, int(ys.max()) + 1


def edges_touched(img: Image.Image, threshold: int = ALPHA_THRESHOLD, tolerance: int = 2) -> int:
    """Quanti dei quattro bordi dell'immagine sono toccati dal soggetto."""
    box = alpha_bbox(img, threshold)
    if box is None:
        return 0
    w, h = img.size
    left, top, right, bottom = box
    return sum((left <= tolerance, top <= tolerance, right >= w - tolerance, bottom >= h - tolerance))


# --------------------------------------------------------------------------- #
# Colore
# --------------------------------------------------------------------------- #


def rgb_to_hsv(rgb: np.ndarray) -> np.ndarray:
    """rgb float in [0,1] (..., 3) -> hsv in [0,1] (..., 3)."""
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    maxc = np.max(rgb, axis=-1)
    minc = np.min(rgb, axis=-1)
    delta = maxc - minc
    s = np.where(maxc > 0, delta / np.where(maxc > 0, maxc, 1), 0.0)
    safe = np.where(delta > 0, delta, 1)
    rc = (maxc - r) / safe
    gc = (maxc - g) / safe
    bc = (maxc - b) / safe
    h = np.where(maxc == r, bc - gc, np.where(maxc == g, 2.0 + rc - bc, 4.0 + gc - rc))
    h = np.where(delta > 0, (h / 6.0) % 1.0, 0.0)
    return np.stack([h, s, maxc], axis=-1)


def hsv_to_rgb(hsv: np.ndarray) -> np.ndarray:
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    i = np.floor(h * 6.0).astype(int) % 6
    f = h * 6.0 - np.floor(h * 6.0)
    p = v * (1 - s)
    q = v * (1 - s * f)
    t = v * (1 - s * (1 - f))
    choices_r = [v, q, p, p, t, v]
    choices_g = [t, v, v, q, p, p]
    choices_b = [p, p, t, v, v, q]
    r = np.choose(i, choices_r)
    g = np.choose(i, choices_g)
    b = np.choose(i, choices_b)
    return np.stack([r, g, b], axis=-1)


def _hue_distance_to_red(h: np.ndarray) -> np.ndarray:
    return np.minimum(h, 1.0 - h)


def dungeondraft_red_mask(rgba: np.ndarray, cfg: RedSettings, safety: float = 1.0) -> np.ndarray:
    """Approssimazione dei pixel che Dungeondraft considera 'custom color'.

    Usa le tre soglie di custom_color_overrides: distanza di tinta dal rosso
    (red_tolerance), rossore minimo (qui R - max(G, B)) e saturazione minima.
    """
    rgb = rgba[..., :3].astype(np.float64) / 255.0
    hsv = rgb_to_hsv(rgb)
    redness = rgb[..., 0] - np.maximum(rgb[..., 1], rgb[..., 2])
    return (
        (rgba[..., 3] > 0)
        & (_hue_distance_to_red(hsv[..., 0]) <= cfg.dd_red_tolerance * safety)
        & (redness >= cfg.dd_min_redness / safety)
        & (hsv[..., 1] >= cfg.dd_min_saturation)
    )


def recolorable_fraction(img: Image.Image, cfg: RedSettings) -> float:
    rgba = np.asarray(img.convert("RGBA"))
    opaque = rgba[..., 3] > 0
    if not opaque.any():
        return 0.0
    return float(dungeondraft_red_mask(rgba, cfg).sum() / opaque.sum())


def normalize_roof_red(img: Image.Image, cfg: RedSettings) -> tuple[Image.Image, float]:
    """Porta i rossi dei tetti a tinta 0 e saturazione uniforme, conservando la luminosità."""
    rgba = np.array(img.convert("RGBA"))
    rgb = rgba[..., :3].astype(np.float64) / 255.0
    hsv = rgb_to_hsv(rgb)
    window = cfg.roof_hue_window_deg / 360.0
    mask = (
        (rgba[..., 3] > 0)
        & (_hue_distance_to_red(hsv[..., 0]) <= window)
        & (hsv[..., 1] >= cfg.roof_min_saturation)
        & (hsv[..., 2] >= cfg.roof_min_value)
    )
    hsv[..., 0] = np.where(mask, 0.0, hsv[..., 0])
    hsv[..., 1] = np.where(mask, cfg.roof_saturation, hsv[..., 1])
    out = hsv_to_rgb(hsv)
    rgba[..., :3] = np.where(mask[..., None], np.round(out * 255.0), rgba[..., :3]).astype(np.uint8)
    opaque = max(int((rgba[..., 3] > 0).sum()), 1)
    return Image.fromarray(rgba, "RGBA"), float(mask.sum() / opaque)


def suppress_red(img: Image.Image, cfg: RedSettings) -> tuple[Image.Image, float]:
    """Sposta su una tinta ocra i pixel che Dungeondraft ricolorerebbe."""
    rgba = np.array(img.convert("RGBA"))
    mask = dungeondraft_red_mask(rgba, cfg, safety=cfg.forbidden_safety)
    if mask.any():
        rgb = rgba[..., :3].astype(np.float64) / 255.0
        hsv = rgb_to_hsv(rgb)
        hsv[..., 0] = np.where(mask, cfg.forbidden_target_hue_deg / 360.0, hsv[..., 0])
        out = hsv_to_rgb(hsv)
        rgba[..., :3] = np.where(mask[..., None], np.round(out * 255.0), rgba[..., :3]).astype(np.uint8)
    opaque = max(int((rgba[..., 3] > 0).sum()), 1)
    return Image.fromarray(rgba, "RGBA"), float(mask.sum() / opaque)


# --------------------------------------------------------------------------- #
# Scala, canvas e ombra
# --------------------------------------------------------------------------- #


def _round_up(value: float, step: int) -> int:
    return int(math.ceil(value / step) * step)


def object_side_for_canvas(canvas: int, scale: ScaleSettings, shadow: ShadowSettings | None) -> int:
    """Lato maggiore dell'oggetto che, centrato, lascia il margine anche all'ombra."""
    extent = shadow.extent if shadow else 0.0
    available_half = canvas / 2.0 - scale.margin * canvas
    return max(1, int(math.floor(available_half / (0.5 + extent))))


def canvas_for_object(side: int, scale: ScaleSettings, shadow: ShadowSettings | None) -> int:
    """Canvas minimo che contiene un oggetto centrato di lato `side`, ombra e margine."""
    extent = shadow.extent if shadow else 0.0
    needed = (side * (0.5 + extent)) / (0.5 - scale.margin)
    return _round_up(needed, scale.round_to)


def target_geometry(spec: SpriteSpec, scale: ScaleSettings, shadow: ShadowSettings) -> tuple[int, int]:
    """(lato oggetto in px, canvas in px) per uno sprite."""
    sh = shadow if spec.shadow else None
    if spec.scale_mode == "reale":
        side = max(1, round(spec.max_size_m * scale.px_per_m))
        canvas = max(spec.canvas, canvas_for_object(side, scale, sh))
        return side, canvas
    return object_side_for_canvas(spec.canvas, scale, sh), spec.canvas


def place_centered(obj: Image.Image, side: int, canvas: int) -> Image.Image:
    """Scala l'oggetto (già ritagliato) a lato maggiore `side` e lo centra sul canvas."""
    w, h = obj.size
    factor = side / max(w, h)
    new_size = (max(1, round(w * factor)), max(1, round(h * factor)))
    scaled = obj.resize(new_size, Image.Resampling.LANCZOS)
    out = Image.new("RGBA", (canvas, canvas), (0, 0, 0, 0))
    out.paste(scaled, ((canvas - new_size[0]) // 2, (canvas - new_size[1]) // 2), scaled)
    return out


def add_shadow(img: Image.Image, side: int, cfg: ShadowSettings) -> Image.Image:
    """Ombra portata in basso a destra (luce da in alto a sinistra)."""
    offset = max(1, round(cfg.offset * side))
    radius = max(0.5, cfg.blur * side)
    alpha = img.getchannel("A")
    shifted = Image.new("L", img.size, 0)
    shifted.paste(alpha, (offset, offset))
    blurred = shifted.filter(ImageFilter.GaussianBlur(radius))
    shadow_alpha = np.asarray(blurred, dtype=np.float64) * cfg.opacity
    layer = np.zeros((img.size[1], img.size[0], 4), dtype=np.uint8)
    layer[..., :3] = cfg.color
    layer[..., 3] = np.clip(np.round(shadow_alpha), 0, 255).astype(np.uint8)
    return Image.alpha_composite(Image.fromarray(layer, "RGBA"), img)


# --------------------------------------------------------------------------- #
# Texture
# --------------------------------------------------------------------------- #


def _crossfade_axis(arr: np.ndarray, axis: int, band: float) -> np.ndarray:
    n = arr.shape[axis]
    rolled = np.roll(arr, n // 2, axis=axis)
    coord = np.arange(n, dtype=np.float64)
    dist_to_edge = np.minimum(coord, n - 1 - coord)
    width = max(1.0, band * n)
    t = np.clip(dist_to_edge / width, 0.0, 1.0)
    weight = t * t * (3 - 2 * t)  # smoothstep: 0 ai bordi, 1 all'interno
    shape = [1, 1, 1]
    shape[axis] = n
    weight = weight.reshape(shape)
    return arr * weight + rolled * (1 - weight)


def make_seamless(img: Image.Image, band: float = 0.2) -> Image.Image:
    """Rende un'immagine piastrellabile sfumando i bordi con la sua copia traslata.

    Al bordo si usa la copia traslata di mezzo lato (continua attraverso il wrap),
    all'interno l'originale: la cucitura della copia cade al centro, dove non pesa.
    Nelle fasce di transizione può comparire un leggero effetto 'doppia immagine'.
    """
    arr = np.asarray(img.convert("RGB"), dtype=np.float64)
    arr = _crossfade_axis(arr, axis=1, band=band)
    arr = _crossfade_axis(arr, axis=0, band=band)
    return Image.fromarray(np.clip(np.round(arr), 0, 255).astype(np.uint8), "RGB")


def seam_ratio(img: Image.Image) -> float:
    """Salto medio attraverso il wrap diviso il salto medio fra pixel adiacenti.

    ~1 = piastrellabile; valori molto maggiori di 1 = cucitura visibile.
    """
    arr = np.asarray(img.convert("RGB"), dtype=np.float64)
    inner_x = np.abs(np.diff(arr, axis=1)).mean()
    inner_y = np.abs(np.diff(arr, axis=0)).mean()
    wrap_x = np.abs(arr[:, 0] - arr[:, -1]).mean()
    wrap_y = np.abs(arr[0, :] - arr[-1, :]).mean()
    inner = max((inner_x + inner_y) / 2.0, 1e-6)
    return float(((wrap_x + wrap_y) / 2.0) / inner)


def center_square(img: Image.Image) -> Image.Image:
    w, h = img.size
    side = min(w, h)
    left, top = (w - side) // 2, (h - side) // 2
    return img.crop((left, top, left + side, top + side))


# --------------------------------------------------------------------------- #
# Pipeline completa
# --------------------------------------------------------------------------- #


def process_texture(raw: Image.Image, spec: SpriteSpec, seamless: bool = True) -> ProcessResult:
    img = center_square(raw.convert("RGB")).resize((spec.canvas, spec.canvas), Image.Resampling.LANCZOS)
    before = seam_ratio(img)
    if seamless:
        img = make_seamless(img)
    after = seam_ratio(img)
    result = ProcessResult(image=img, info={"cucitura_prima": round(before, 2), "cucitura_dopo": round(after, 2)})
    if after > 1.6:
        result.warnings.append(f"texture ancora poco piastrellabile (rapporto cucitura {after:.2f})")
    return result


def process_object(
    raw: Image.Image,
    spec: SpriteSpec,
    scale: ScaleSettings,
    shadow: ShadowSettings,
    red: RedSettings,
    background_removal: str = "auto",
    rembg_model: str = "birefnet-general",
) -> ProcessResult:
    warnings: list[str] = []
    info: dict[str, object] = {}
    img = raw.convert("RGBA")

    needs_removal = background_removal == "sempre" or (
        background_removal == "auto" and not has_real_alpha(img)
    )
    if needs_removal:
        img = remove_background(img, rembg_model)
        info["scontorno"] = rembg_model
    elif not has_real_alpha(img):
        raise ProcessingError("l'immagine non ha trasparenza e lo scontorno è disattivato")

    img = clean_alpha(img)
    touched = edges_touched(img)
    if touched >= 2:
        warnings.append(
            f"il soggetto tocca {touched} bordi dell'immagine generata: "
            "probabile sfondo rimasto o soggetto tagliato"
        )

    box = alpha_bbox(img)
    if box is None:
        raise ProcessingError("dopo lo scontorno l'immagine è vuota")
    obj = img.crop(box)

    side, canvas = target_geometry(spec, scale, shadow)
    info.update({"lato_oggetto_px": side, "canvas_px": canvas})
    if canvas != spec.canvas:
        info["canvas_ampliato_da"] = spec.canvas

    sprite = place_centered(obj, side, canvas)

    # I rossi si sistemano alla risoluzione finale, così il resize non li altera.
    if spec.red_mode == "tetto":
        sprite, fraction = normalize_roof_red(sprite, red)
        info["rosso_normalizzato"] = round(fraction, 4)
    elif spec.red_mode == "vietato":
        sprite, fraction = suppress_red(sprite, red)
        info["rosso_rimosso"] = round(fraction, 4)

    if spec.shadow:
        sprite = add_shadow(sprite, side, shadow)

    warnings.extend(validate_object(sprite, spec, scale, red, obj_size=obj.size))
    info["ricolorabile"] = round(recolorable_fraction(sprite, red), 4)
    return ProcessResult(image=sprite, warnings=warnings, info=info)


def validate_object(
    sprite: Image.Image,
    spec: SpriteSpec,
    scale: ScaleSettings,
    red: RedSettings,
    obj_size: tuple[int, int] | None = None,
) -> list[str]:
    warnings: list[str] = []
    if sprite.mode != "RGBA" or not has_real_alpha(sprite):
        warnings.append("manca un canale alfa con trasparenza reale")

    w, h = sprite.size
    if w != h:
        warnings.append(f"canvas non quadrato ({w}x{h})")

    box = alpha_bbox(sprite, threshold=24)
    if box is not None:
        limit = math.floor(scale.margin * w * 0.5)  # tolleranza: metà del margine richiesto
        left, top, right, bottom = box
        if min(left, top, w - right, h - bottom) < limit:
            warnings.append("il contenuto invade il margine trasparente")

    if obj_size and spec.size_m and len(spec.size_m) >= 2:
        expected = max(spec.size_m) / min(spec.size_m)
        actual = max(obj_size) / max(min(obj_size), 1)
        if actual / expected > 1.35 or expected / actual > 1.35:
            warnings.append(
                f"proporzioni {actual:.2f}:1 lontane da quelle attese {expected:.2f}:1"
            )

    fraction = recolorable_fraction(sprite, red)
    if spec.red_mode == "tetto" and fraction < 0.02:
        warnings.append(f"quasi nessun pixel ricolorabile ({fraction:.1%}): tetto rosso non riconosciuto")
    if spec.red_mode == "vietato" and fraction > 0.002:
        warnings.append(f"restano pixel ricolorabili ({fraction:.1%}) in uno sprite che non deve cambiare colore")
    return warnings


def save_png(img: Image.Image, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path, format="PNG", optimize=True)
    with path.open("rb") as fh:
        if fh.read(8) != PNG_SIGNATURE:  # pragma: no cover - difesa
            raise ProcessingError(f"{path} non è un PNG valido")
