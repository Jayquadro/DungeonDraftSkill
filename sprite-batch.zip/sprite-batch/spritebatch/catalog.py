"""Caricamento del catalogo YAML: impostazioni globali ed elenco degli sprite."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

NAME_RE = re.compile(r"^[a-z0-9]+(?:_[a-z0-9]+)*$")
KINDS = ("oggetto", "texture")
SCALE_MODES = ("canvas", "reale")
RED_MODES = ("tetto", "vietato", "libero")


class CatalogError(ValueError):
    """Errore di struttura o di contenuto nel catalogo."""


# --------------------------------------------------------------------------- #
# Impostazioni
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class PackSettings:
    name: str = "Nova Mistralis Città"
    folder: str = "NovaMistralisCitta"
    author: str = ""
    version: str = "1.0"
    id: str = ""
    metadata_files: tuple[str, ...] = ("pack.json",)


@dataclass(frozen=True)
class ScaleSettings:
    grid_px: int = 256
    grid_m: float = 1.5
    margin: float = 0.05
    round_to: int = 16

    @property
    def px_per_m(self) -> float:
        return self.grid_px / self.grid_m


@dataclass(frozen=True)
class ShadowSettings:
    offset: float = 0.04  # frazione del lato maggiore dell'oggetto
    blur: float = 0.025  # raggio di sfocatura, frazione del lato maggiore
    opacity: float = 0.45
    color: tuple[int, int, int] = (22, 16, 10)

    @property
    def extent(self) -> float:
        """Di quanto l'ombra sporge oltre l'oggetto, come frazione del lato maggiore."""
        return self.offset + 2.0 * self.blur


@dataclass(frozen=True)
class RedSettings:
    # Soglie di Dungeondraft (custom_color_overrides del pack)
    dd_min_redness: float = 0.1
    dd_min_saturation: float = 0.0
    dd_red_tolerance: float = 0.04
    # Normalizzazione dei tetti
    roof_hue_window_deg: float = 25.0
    roof_min_saturation: float = 0.35
    roof_min_value: float = 0.15
    roof_saturation: float = 0.85
    # Sprite in cui il rosso è vietato: i rossi vengono spostati su questa tinta
    forbidden_target_hue_deg: float = 26.0
    forbidden_safety: float = 1.5


@dataclass(frozen=True)
class GenerationSettings:
    backend: str = "openai"
    model: str = "gpt-image-2"
    size: str = "1024x1024"
    quality: str = "high"
    candidates: int = 2
    parallel: int = 2
    anchors: tuple[str, ...] = ()
    comfyui_url: str = "http://127.0.0.1:8188"
    comfyui_workflow: str = ""


@dataclass(frozen=True)
class Settings:
    pack: PackSettings = field(default_factory=PackSettings)
    scale: ScaleSettings = field(default_factory=ScaleSettings)
    shadow: ShadowSettings = field(default_factory=ShadowSettings)
    red: RedSettings = field(default_factory=RedSettings)
    generation: GenerationSettings = field(default_factory=GenerationSettings)


# --------------------------------------------------------------------------- #
# Sprite
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class SpriteSpec:
    name: str  # senza prefisso nm_
    category: str
    kind: str
    canvas: int
    scale_mode: str
    red_mode: str
    subject: str
    size_m: tuple[float, ...] | None
    shadow: bool
    folders: tuple[str, ...]

    @property
    def stem(self) -> str:
        return f"nm_{self.name}"

    @property
    def filename(self) -> str:
        return f"{self.stem}.png"

    @property
    def max_size_m(self) -> float | None:
        return max(self.size_m) if self.size_m else None


@dataclass(frozen=True)
class Catalog:
    settings: Settings
    sprites: tuple[SpriteSpec, ...]

    def by_stem(self) -> dict[str, SpriteSpec]:
        return {s.stem: s for s in self.sprites}

    def select(
        self,
        only: list[str] | None = None,
        categories: list[str] | None = None,
        anchors: bool = False,
    ) -> list[SpriteSpec]:
        chosen = list(self.sprites)
        if anchors:
            wanted = set(self.settings.generation.anchors)
            chosen = [s for s in chosen if s.stem in wanted]
        if categories:
            cats = {c.upper() for c in categories}
            chosen = [s for s in chosen if s.category.upper() in cats]
        if only:
            wanted = {_normalize_stem(n) for n in only}
            unknown = wanted - {s.stem for s in self.sprites}
            if unknown:
                raise CatalogError(f"sprite sconosciuti: {', '.join(sorted(unknown))}")
            chosen = [s for s in chosen if s.stem in wanted]
        return chosen


def _normalize_stem(name: str) -> str:
    name = name.strip().removesuffix(".png")
    return name if name.startswith("nm_") else f"nm_{name}"


# --------------------------------------------------------------------------- #
# Parsing
# --------------------------------------------------------------------------- #


def load_catalog(path: str | Path) -> Catalog:
    data = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise CatalogError("il catalogo deve essere un mapping YAML")
    return parse_catalog(data)


def parse_catalog(data: dict[str, Any]) -> Catalog:
    settings = _parse_settings(data)
    categories = data.get("categorie") or {}
    if not isinstance(categories, dict) or not categories:
        raise CatalogError("sezione 'categorie' mancante o vuota")

    sprites: list[SpriteSpec] = []
    for raw in data.get("sprite") or []:
        sprites.extend(_expand_entry(raw, categories))

    seen: set[str] = set()
    for spec in sprites:
        if spec.stem in seen:
            raise CatalogError(f"nome duplicato: {spec.stem}")
        seen.add(spec.stem)

    missing = set(settings.generation.anchors) - seen
    if missing:
        raise CatalogError(f"ancore non presenti nel catalogo: {', '.join(sorted(missing))}")

    return Catalog(settings=settings, sprites=tuple(sprites))


def _parse_settings(data: dict[str, Any]) -> Settings:
    pack = data.get("pacchetto") or {}
    scale = data.get("scala") or {}
    shadow = data.get("ombra") or {}
    red = data.get("rosso") or {}
    gen = data.get("generazione") or {}
    dd = red.get("dungeondraft") or {}
    roof = red.get("tetti") or {}
    forbidden = red.get("vietato") or {}

    return Settings(
        pack=PackSettings(
            name=str(pack.get("nome", PackSettings.name)),
            folder=str(pack.get("cartella", PackSettings.folder)),
            author=str(pack.get("autore", PackSettings.author)),
            version=str(pack.get("versione", PackSettings.version)),
            id=str(pack.get("id", "") or ""),
            metadata_files=tuple(pack.get("file_metadati", PackSettings.metadata_files)),
        ),
        scale=ScaleSettings(
            grid_px=int(scale.get("griglia_px", ScaleSettings.grid_px)),
            grid_m=float(scale.get("griglia_m", ScaleSettings.grid_m)),
            margin=float(scale.get("margine", ScaleSettings.margin)),
            round_to=int(scale.get("arrotonda_canvas_a", ScaleSettings.round_to)),
        ),
        shadow=ShadowSettings(
            offset=float(shadow.get("offset", ShadowSettings.offset)),
            blur=float(shadow.get("sfocatura", ShadowSettings.blur)),
            opacity=float(shadow.get("opacita", ShadowSettings.opacity)),
            color=tuple(int(c) for c in shadow.get("colore", ShadowSettings.color)),
        ),
        red=RedSettings(
            dd_min_redness=float(dd.get("min_redness", RedSettings.dd_min_redness)),
            dd_min_saturation=float(dd.get("min_saturation", RedSettings.dd_min_saturation)),
            dd_red_tolerance=float(dd.get("red_tolerance", RedSettings.dd_red_tolerance)),
            roof_hue_window_deg=float(roof.get("finestra_tinta_gradi", RedSettings.roof_hue_window_deg)),
            roof_min_saturation=float(roof.get("saturazione_minima", RedSettings.roof_min_saturation)),
            roof_min_value=float(roof.get("luminosita_minima", RedSettings.roof_min_value)),
            roof_saturation=float(roof.get("saturazione_finale", RedSettings.roof_saturation)),
            forbidden_target_hue_deg=float(
                forbidden.get("tinta_sostitutiva_gradi", RedSettings.forbidden_target_hue_deg)
            ),
            forbidden_safety=float(forbidden.get("margine_sicurezza", RedSettings.forbidden_safety)),
        ),
        generation=GenerationSettings(
            backend=str(gen.get("backend", GenerationSettings.backend)),
            model=str(gen.get("modello", GenerationSettings.model)),
            size=str(gen.get("dimensione", GenerationSettings.size)),
            quality=str(gen.get("qualita", GenerationSettings.quality)),
            candidates=int(gen.get("candidati", GenerationSettings.candidates)),
            parallel=int(gen.get("parallelo", GenerationSettings.parallel)),
            anchors=tuple(_normalize_stem(a) for a in gen.get("ancore", []) or []),
            comfyui_url=str(gen.get("comfyui_url", GenerationSettings.comfyui_url)),
            comfyui_workflow=str(gen.get("comfyui_workflow", "") or ""),
        ),
    )


def _expand_entry(raw: dict[str, Any], categories: dict[str, Any]) -> list[SpriteSpec]:
    if not isinstance(raw, dict) or "nome" not in raw or "categoria" not in raw:
        raise CatalogError(f"voce sprite senza 'nome' o 'categoria': {raw!r}")

    cat_key = str(raw["categoria"])
    if cat_key not in categories:
        raise CatalogError(f"{raw['nome']}: categoria sconosciuta '{cat_key}'")
    merged = {**(categories[cat_key] or {}), **raw}

    variants = raw.get("varianti")
    if variants is None:
        return [_build_spec(str(raw["nome"]), cat_key, merged, str(raw.get("soggetto", "")), None)]

    template = str(raw["nome"])
    if "{i" not in template:
        raise CatalogError(f"{template}: le voci con varianti devono contenere '{{i}}' nel nome")
    if not isinstance(variants, list) or not variants:
        raise CatalogError(f"{template}: 'varianti' deve essere una lista non vuota")

    specs = []
    base_subject = str(raw.get("soggetto", "")).strip()
    for index, variant in enumerate(variants, start=1):
        if isinstance(variant, str):
            variant = {"soggetto": variant}
        subject = ". ".join(p for p in (base_subject.rstrip("."), str(variant.get("soggetto", "")).strip()) if p)
        name = template.format(i=index)
        specs.append(_build_spec(name, cat_key, {**merged, **variant}, subject, index))
    return specs


def _build_spec(
    name: str, category: str, merged: dict[str, Any], subject: str, variant: int | None
) -> SpriteSpec:
    if not NAME_RE.match(name):
        raise CatalogError(f"nome non valido '{name}': solo minuscole ASCII, cifre e underscore")
    if not subject.strip():
        raise CatalogError(f"nm_{name}: 'soggetto' vuoto")

    kind = str(merged.get("tipo", "oggetto"))
    if kind not in KINDS:
        raise CatalogError(f"nm_{name}: tipo '{kind}' non valido ({', '.join(KINDS)})")

    scale_mode = str(merged.get("scala", "canvas"))
    if scale_mode not in SCALE_MODES:
        raise CatalogError(f"nm_{name}: scala '{scale_mode}' non valida ({', '.join(SCALE_MODES)})")

    red_mode = str(merged.get("rosso", "libero"))
    if red_mode not in RED_MODES:
        raise CatalogError(f"nm_{name}: rosso '{red_mode}' non valido ({', '.join(RED_MODES)})")

    canvas = int(merged.get("canvas", 0))
    if canvas <= 0:
        raise CatalogError(f"nm_{name}: 'canvas' mancante o non positivo")

    size_m = merged.get("dimensioni_m")
    if size_m is not None:
        if isinstance(size_m, (int, float)):
            size_m = [size_m]
        size_m = tuple(float(v) for v in size_m)
        if not size_m or any(v <= 0 or math.isnan(v) for v in size_m):
            raise CatalogError(f"nm_{name}: 'dimensioni_m' deve contenere valori positivi")
    if scale_mode == "reale" and kind == "oggetto" and not size_m:
        raise CatalogError(f"nm_{name}: la scala 'reale' richiede 'dimensioni_m'")

    default_folders = ["textures/terrain"] if kind == "texture" else ["textures/objects"]
    folders = tuple(str(f).strip("/") for f in merged.get("cartelle", default_folders))

    return SpriteSpec(
        name=name,
        category=category,
        kind=kind,
        canvas=canvas,
        scale_mode=scale_mode if kind == "oggetto" else "canvas",
        red_mode=red_mode,
        subject=subject.strip(),
        size_m=size_m,
        shadow=bool(merged.get("ombra", kind == "oggetto")),
        folders=folders,
    )
