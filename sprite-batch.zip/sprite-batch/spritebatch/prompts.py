"""Prompt per il modello di immagini, in inglese (i modelli rispondono meglio).

Rispetto al brief originale cambiano due cose, di proposito:
- niente ombra portata: la aggiunge il post-processing, identica per tutti;
- niente vincoli in pixel o margini: li impone il post-processing.
"""

from __future__ import annotations

from .catalog import SpriteSpec

OBJECT_BRIEF = """\
Asset for a hand-painted fantasy city battlemap, to be placed in Dungeondraft.
VIEW: strict orthographic plan view from directly above (90 degrees), like a satellite photo. \
Only roofs, courtyards and ground-level objects are visible. No facades, no walls seen from the side, \
no perspective, no isometric angle, no vanishing point.
ISOLATION: one single isolated subject on a fully transparent background. Include only the subject \
and the ground that strictly belongs to it (for example its own fenced yard). No grass, sea, trees, \
hills, roads or neighbouring buildings around it. Do not crop the subject: leave empty space on every side.
STYLE: warm hand-painted illustration, like a medieval European city map in a tabletop RPG sourcebook. \
Soft brushwork, subtle texture. Not pixel art, not flat vector, not photorealistic.
LIGHT: soft light from the top-left for volume shading. Do NOT paint any cast shadow on the ground.
PALETTE: earthy natural tones: grey and ochre stone, brown wood, pale plaster, muted greens. \
No neon or acid colours.
CONSISTENCY: this is one asset of a large set seen side by side. Keep brushwork thickness, texture grain \
and saturation identical across the set, and render recurring materials (roof tiles, thatch, stone, \
plaster, wood, water) the same way every time."""

TEXTURE_BRIEF = """\
Seamless tileable ground texture for a hand-painted fantasy city battlemap, seen from directly above.
The texture fills the entire square image edge to edge: no border, no vignette, no frame, no objects, \
no directional shadows, even lighting, uniform density so that repeated tiles show no pattern.
STYLE: warm hand-painted illustration, soft brushwork, subtle texture. Not photorealistic, not pixel art.
PALETTE: earthy natural tones, muted and never saturated."""

REFERENCE_NOTE = """\
REFERENCES: the attached images are other assets from the same set. Match their brushwork, palette, \
lighting and top-down view exactly, but draw a new, different subject as described below. \
Do not copy their content or layout."""

RED_RULES = {
    "tetto": (
        "ROOFS: paint every roof in a uniform, saturated brick red; this colour is a recolour channel. "
        "Nothing else in the image may be saturated red."
    ),
    "vietato": "COLOUR: no red and no saturated reddish tones anywhere; use ochre, brown and grey instead.",
    "libero": "",
}


def _size_hint(spec: SpriteSpec) -> str:
    if not spec.size_m:
        return ""
    if len(spec.size_m) == 1:
        return f"Approximate real size: {spec.size_m[0]:g} m across."
    dims = " x ".join(f"{v:g}" for v in spec.size_m)
    return f"Approximate real footprint: {dims} m."


def build_prompt(spec: SpriteSpec, has_references: bool = False) -> str:
    if spec.kind == "texture":
        parts = [TEXTURE_BRIEF, f"SUBJECT: {spec.subject.rstrip('. ')}."]
    else:
        parts = [OBJECT_BRIEF]
        if has_references:
            parts.append(REFERENCE_NOTE)
        rule = RED_RULES[spec.red_mode]
        if rule:
            parts.append(rule)
        subject = spec.subject.rstrip(". ") + "."
        parts.append(f"SUBJECT: {subject} {_size_hint(spec)}".strip())
    return "\n\n".join(parts)
