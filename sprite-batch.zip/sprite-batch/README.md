# spritebatch

Generazione batch del pacchetto sprite **Nova Mistralis Città** per Dungeondraft:
genera i candidati con un modello di immagini, li post-elabora in modo deterministico
e assembla la cartella del pack.

Il modello si occupa solo di disegnare. Tutto ciò che il brief richiede in modo misurabile
(trasparenza, margini, scala, direzione dell'ombra, rosso ricolorabile, piastrellabilità)
lo impone il post-processing, identico per ogni sprite.

## Installazione

```bash
python -m venv .venv && .venv\Scripts\activate      # Windows
pip install -e ".[openai,scontorno,test]"
set OPENAI_API_KEY=sk-...                            # PowerShell: $env:OPENAI_API_KEY="sk-..."
```

`rembg` serve solo se il modello restituisce sfondi opachi. Al primo uso scarica il modello
di scontorno (`birefnet-general`, circa 1 GB). Con una GPU NVIDIA usa `rembg[gpu]`.

## Flusso di lavoro

```bash
# 0. Controlla il catalogo: canvas e lato oggetto calcolati per ogni sprite
python -m spritebatch lista
python -m spritebatch prompt taverna casa_01

# 1. Prova la pipeline senza spendere nulla
python -m spritebatch --lavoro prova tutto --backend finto

# 2. Genera solo le ancore (casa_01, taverna, albero_1, banco_mercato_1)
python -m spritebatch genera --ancore --candidati 4

# 3. Guarda i candidati in lavoro/grezzi/<nome>/, annota i migliori in
#    lavoro/scelte.yaml (es. "nm_taverna: 3") e copiali come riferimenti.
#    Si copiano i grezzi, senza l'ombra aggiunta, per non insegnarla al modello.
python -m spritebatch riferimenti

# 4. Genera il resto usando i riferimenti
python -m spritebatch genera --riferimenti riferimenti --dry-run   # quante chiamate
python -m spritebatch genera --riferimenti riferimenti

# 5. Rivedi i candidati e aggiorna lavoro/scelte.yaml (senza voce si usa c1)
python -m spritebatch elabora
#    leggi lavoro/rapporto.json: gli sprite con "stato": "avvisi" vanno guardati

# 6. Rigenera ciò che non va e assembla il pack
python -m spritebatch genera --solo carro,faro --forza --riferimenti riferimenti
python -m spritebatch elabora --solo carro,faro
python -m spritebatch pacchetto
```

Il pack finisce in `dist/NovaMistralisCitta/`, con `pack.json`, `textures/objects/`,
`textures/terrain/`, `textures/patterns/normal/` e `preview.png` (il provino di tutti
gli sprite, utile per giudicare la coerenza). Il file `.dungeondraft_pack` lo produce il
packer di Dungeondraft a partire da quella cartella.

`genera` salta gli sprite che hanno già dei candidati, quindi puoi interromperlo e rilanciarlo.
Filtri disponibili per tutti i comandi: `--solo a,b`, `--categoria C3`, `--ancore`.

## Cosa fa il post-processing

| Passo | Dettaglio |
|---|---|
| Scontorno | `auto`: solo se l'immagine non ha trasparenza reale (anche una scacchiera dipinta viene riconosciuta come opaca). `sempre` / `mai` per forzare. |
| Ritaglio e scala | `scala: canvas` fa riempire il canvas all'oggetto; `scala: reale` usa 256 px = 1,5 m e allarga il canvas se serve. |
| Centratura | L'oggetto (non l'ombra) è centrato: per `nm_porta_mura` l'apertura cade al centro. |
| Rosso `tetto` | I rossi entro ±25° di tinta vanno a tinta 0 e saturazione 0,85, luminosità invariata. |
| Rosso `vietato` | I pixel che Dungeondraft ricolorerebbe vengono spostati su una tinta ocra. |
| Ombra | Aggiunta via codice in basso a destra; sporgenza 9% del lato maggiore, sotto il 10% del brief. |
| Texture | Ritaglio quadrato, resize, bordi sfumati con la copia traslata per renderle piastrellabili. |
| Validazione | Alfa reale, margine, proporzioni rispetto a `dimensioni_m`, pixel ricolorabili, soggetto che tocca i bordi. |

Il criterio "ricolorabile" riproduce le tre soglie di `custom_color_overrides`
(`min_redness`, `min_saturation`, `red_tolerance`). Il rossore è approssimato come
R − max(G, B): verifica in Dungeondraft su un paio di sprite prima di fidarti al 100%.

## Backend

**openai** (predefinito): `gpt-image-2`, con `background: transparent` e output PNG.
Con dei riferimenti usa l'endpoint di edit (massimo 16 immagini). Se il modello rifiuta
la trasparenza, passa da solo a sfondo opaco e lo scontorno locale se ne occupa.

**comfyui**: esporta il workflow con *Save (API Format)* e nel JSON sostituisci
il testo del prompt positivo con `%PROMPT%` (può anche stare dentro una frase, es.
`"nmstyle, %PROMPT%"` con il trigger della tua LoRA) e il valore del seed con `"%SEED%"`.
Poi:

```bash
python -m spritebatch genera --backend comfyui --workflow workflow_api.json
```

I riferimenti di stile qui non vengono inviati: su ComfyUI lo stile lo dà la LoRA.
FLUX non produce alfa, quindi lo scontorno automatico entrerà sempre in funzione.
Se sulla stessa GPU gira Ollama, scarica prima il modello (`ollama stop <modello>`).

**finto**: forme segnaposto, per provare la pipeline e i test.

## Scelte da rivedere nel catalogo

- **Scala**: C4 usa `reale` (256 px = 1,5 m), tutte le altre categorie `canvas`.
  Di conseguenza i pezzi C4 hanno canvas più grandi dei 256×256 del brief:
  un carro da 3 m è un oggetto di 512 px su un canvas di 672. `python -m spritebatch lista` li mostra tutti.
- **Rosso**: `tetto` per C2, C3 e C6; `vietato` per case povere, faro, prigione, torre di guardia,
  porta delle mura e texture; `libero` per monumenti, tempio e pezzi C4.
- **Metadati**: il brief parla di `data.json`, i packer leggono `pack.json`.
  Viene scritto `pack.json`; aggiungi `data.json` a `pacchetto.file_metadati` se ti serve.

## Test

```bash
pytest
```

I test che producono immagini salvano gli artefatti in `tests/artifacts_output/`.
